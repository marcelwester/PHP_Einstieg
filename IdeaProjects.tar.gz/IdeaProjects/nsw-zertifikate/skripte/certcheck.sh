#!/bin/bash

TMP=`date +"%s%N"`
ERRORFILE="/tmp/check_${TMP}";

DEBUG=0;

echo 0 > "${ERRORFILE}"
find ${CERTDIR} -name *.pem | while read LINE; do
  if [ "$DEBUG" -gt "0" ]; then
    echo
    echo "================================================================================="
    echo "${LINE}"
  fi
  ${CERTCHECK} ${DAYS} ${LINE}
  if [ "$?" != "0" ]; then
      notify=1
      echo "${LINE}"
      echo ${EXCLUDE} | grep ${LINE} 1>/dev/null 2>&1
      if [ "$?" == "0" ]; then
            echo "$LINE in Exclude"
            notify=0
       fi
       if [ "${notify}" == "1" ]; then
         echo 1 > "${ERRORFILE}"
       fi
       echo
  fi
done

ERROR=`cat "${ERRORFILE}"`
exit $ERROR;






