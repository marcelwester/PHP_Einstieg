#!/bin/bash

export EXCLUDE="/opt/htdocs/dev/IdeaProjects/nsw-zertifikate/zertifikate/wirksystem/api/webserver/client/test.pem
/opt/htdocs/dev/IdeaProjects/nsw-zertifikate/zertifikate/wirksystem/api/webserver/server/test.pem"

#export EXCLUDE="/opt/htdocs/dev/IdeaProjects/nsw-zertifikate/zertifikate/wirksystem/api/webserver/client/test.pem"



export CERTDIR="/opt/htdocs/dev/IdeaProjects/nsw-zertifikate/zertifikate"
export CERTCHECK="php /opt/htdocs/dev/IdeaProjects/nsw-zertifikate/skripte/certcheck.php"

export DAYS=100

MONITOR=certcheck
MONITOR_URL="http://127.0.0.1/dev/statusMonitor/mon_upload.php";


TMP=`date +"%s%N"`
LOGFILE="/tmp/certcheck_${TMP}.log"

STATUS=0
./certcheck.sh  1>${LOGFILE} 2>&1
if [ "$?" == "0" ]; then
   STATUS=1;
fi

curl -F "file=@${LOGFILE}" "${MONITOR_URL}?mon=${MONITOR}&status=${STATUS}"

exit 0
