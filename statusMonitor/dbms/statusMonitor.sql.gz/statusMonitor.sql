-- MySQL dump 10.14  Distrib 5.5.50-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: statusMonitor
-- ------------------------------------------------------
-- Server version	5.5.50-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sys_log`
--

DROP TABLE IF EXISTS `sys_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `message` text,
  `user` varchar(100) NOT NULL DEFAULT '',
  `ts` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ip` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_sys_log_ts` (`ts`)
) ENGINE=MyISAM AUTO_INCREMENT=1422 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_log`
--

LOCK TABLES `sys_log` WRITE;
/*!40000 ALTER TABLE `sys_log` DISABLE KEYS */;
INSERT INTO `sys_log` VALUES (1419,'Login','Volker Losch','2017-02-11 15:14:26','192.168.167.51'),(1420,'Login','Volker Losch','2017-02-12 09:50:21','192.168.167.51'),(1421,'Login','Volker Losch','2017-04-13 22:10:14','192.168.167.51');
/*!40000 ALTER TABLE `sys_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_log_visits`
--

DROP TABLE IF EXISTS `sys_log_visits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_log_visits` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ip` varchar(16) NOT NULL DEFAULT '',
  `site` varchar(64) NOT NULL DEFAULT '',
  `url` text NOT NULL,
  `toc_ts` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18008 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_log_visits`
--

LOCK TABLES `sys_log_visits` WRITE;
/*!40000 ALTER TABLE `sys_log_visits` DISABLE KEYS */;
INSERT INTO `sys_log_visits` VALUES (17930,'192.168.167.51','aktion.php','/dev2_COS7/statusMonitor/','2017-02-11 15:14:19'),(17931,'192.168.167.51','login.php','/dev2_COS7/statusMonitor/','2017-02-11 15:14:19'),(17932,'192.168.167.51','login.php','/dev2_COS7/statusMonitor/index.php?site=login&action=check&PHPSESSID=e3325o7ke5ldbhr8sk2v1i35m6','2017-02-11 15:14:26'),(17933,'192.168.167.51','login.php','/dev2_COS7/statusMonitor/index.php?site=login&action=check&PHPSESSID=e3325o7ke5ldbhr8sk2v1i35m6','2017-02-11 15:14:26'),(17934,'192.168.167.51','aktion.php','/dev2_COS7/statusMonitor/index.php?site=aktion&showinfo=1&PHPSESSID=e3325o7ke5ldbhr8sk2v1i35m6','2017-02-11 15:14:27'),(17935,'192.168.167.51','aktion.php','/dev2_COS7/statusMonitor/','2017-02-12 09:50:16'),(17936,'192.168.167.51','login.php','/dev2_COS7/statusMonitor/','2017-02-12 09:50:16'),(17937,'192.168.167.51','login.php','/dev2_COS7/statusMonitor/index.php?site=login&action=check&PHPSESSID=mmskt23mt88sboa6sjqcat7rl2','2017-02-12 09:50:21'),(17938,'192.168.167.51','login.php','/dev2_COS7/statusMonitor/index.php?site=login&action=check&PHPSESSID=mmskt23mt88sboa6sjqcat7rl2','2017-02-12 09:50:21'),(17939,'192.168.167.51','aktion.php','/dev2_COS7/statusMonitor/index.php?site=aktion&showinfo=1&PHPSESSID=mmskt23mt88sboa6sjqcat7rl2','2017-02-12 09:50:22'),(17940,'192.168.167.51','admin.php','/dev2_COS7/statusMonitor/index.php?site=admin&PHPSESSID=mmskt23mt88sboa6sjqcat7rl2','2017-02-12 09:50:23'),(17941,'192.168.167.51','admin.php','/dev2_COS7/statusMonitor/index.php?site=admin&PHPSESSID=mmskt23mt88sboa6sjqcat7rl2','2017-02-12 09:50:23'),(17942,'192.168.167.51','admin.php','/dev2_COS7/statusMonitor/index.php?site=admin&admsite=user&PHPSESSID=mmskt23mt88sboa6sjqcat7rl2','2017-02-12 09:50:26'),(17943,'192.168.167.51','admin.php','/dev2_COS7/statusMonitor/index.php?site=admin&admsite=user&PHPSESSID=mmskt23mt88sboa6sjqcat7rl2','2017-02-12 09:50:26'),(17944,'192.168.167.51','adm_user.php','/dev2_COS7/statusMonitor/index.php?site=admin&admsite=user&PHPSESSID=mmskt23mt88sboa6sjqcat7rl2','2017-02-12 09:50:26'),(17945,'192.168.167.51','monitor_popup.php','/dev/statusMonitor_PDO/mon.php','2017-04-13 22:01:44'),(17946,'192.168.167.51','monitor.php','/dev/statusMonitor_PDO/mon.php','2017-04-13 22:01:44'),(17947,'192.168.167.51','monitor_popup.php','/dev/statusMonitor_PDO/mon.php','2017-04-13 22:02:00'),(17948,'192.168.167.51','monitor.php','/dev/statusMonitor_PDO/mon.php','2017-04-13 22:02:00'),(17949,'192.168.167.51','monitor_popup.php','/dev/statusMonitor_PDO/monitor_popup.php?monitorid=24&PHPSESSID=7erciavp5u58qudkm0ols3gq51','2017-04-13 22:02:13'),(17950,'192.168.167.51','monitor_popup.php','/dev/statusMonitor_PDO/mon.php','2017-04-13 22:04:25'),(17951,'192.168.167.51','monitor.php','/dev/statusMonitor_PDO/mon.php','2017-04-13 22:04:25'),(17952,'192.168.167.51','monitor_popup.php','/dev/statusMonitor_PDO/mon.php','2017-04-13 22:05:02'),(17953,'192.168.167.51','monitor.php','/dev/statusMonitor_PDO/mon.php','2017-04-13 22:05:02'),(17954,'192.168.167.51','monitor_popup.php','/dev/statusMonitor_PDO/mon.php','2017-04-13 22:08:17'),(17955,'192.168.167.51','monitor.php','/dev/statusMonitor_PDO/mon.php','2017-04-13 22:08:17'),(17956,'192.168.167.51','monitor_popup.php','/dev/statusMonitor_PDO/mon.php','2017-04-13 22:08:24'),(17957,'192.168.167.51','monitor.php','/dev/statusMonitor_PDO/mon.php','2017-04-13 22:08:24'),(17958,'192.168.167.51','monitor_popup.php','/dev/statusMonitor_PDO/monitor_popup.php?monitorid=24&PHPSESSID=7erciavp5u58qudkm0ols3gq51','2017-04-13 22:08:25'),(17959,'192.168.167.51','monitor_popup.php','/dev/statusMonitor_PDO/mon.php','2017-04-13 22:10:08'),(17960,'192.168.167.51','monitor.php','/dev/statusMonitor_PDO/mon.php','2017-04-13 22:10:08'),(17961,'192.168.167.51','aktion.php','/dev/statusMonitor_PDO/index.php','2017-04-13 22:10:10'),(17962,'192.168.167.51','login.php','/dev/statusMonitor_PDO/index.php','2017-04-13 22:10:10'),(17963,'192.168.167.51','login.php','/dev/statusMonitor_PDO/index.php?site=login&action=check&PHPSESSID=7erciavp5u58qudkm0ols3gq51','2017-04-13 22:10:14'),(17964,'192.168.167.51','login.php','/dev/statusMonitor_PDO/index.php?site=login&action=check&PHPSESSID=7erciavp5u58qudkm0ols3gq51','2017-04-13 22:10:14'),(17965,'192.168.167.51','aktion.php','/dev/statusMonitor_PDO/index.php?site=aktion&showinfo=1&PHPSESSID=7erciavp5u58qudkm0ols3gq51','2017-04-13 22:10:15'),(17966,'192.168.167.51','admin.php','/dev/statusMonitor_PDO/index.php?site=admin&PHPSESSID=7erciavp5u58qudkm0ols3gq51','2017-04-13 22:10:15'),(17967,'192.168.167.51','admin.php','/dev/statusMonitor_PDO/index.php?site=admin&PHPSESSID=7erciavp5u58qudkm0ols3gq51','2017-04-13 22:10:15'),(17968,'192.168.167.51','aktion.php','/dev/statusMonitor_PDO/index.php?site=aktion&PHPSESSID=7erciavp5u58qudkm0ols3gq51','2017-04-13 22:10:16'),(17969,'192.168.167.51','monitor.php','/dev/statusMonitor_PDO/index.php?site=monitor&PHPSESSID=7erciavp5u58qudkm0ols3gq51','2017-04-13 22:10:17'),(17970,'192.168.167.51','monitor.php','/dev/statusMonitor_PDO/index.php?site=monitor&PHPSESSID=7erciavp5u58qudkm0ols3gq51','2017-04-13 22:10:17'),(17971,'192.168.167.51','monitor_popup.php','/dev/statusMonitor_PDO/mon.php','2017-04-13 22:13:10'),(17972,'192.168.167.51','monitor.php','/dev/statusMonitor_PDO/mon.php','2017-04-13 22:13:10'),(17973,'192.168.167.51','monitor_popup.php','/dev/statusMonitor_PDO/mon.php','2017-04-13 22:13:29'),(17974,'192.168.167.51','monitor.php','/dev/statusMonitor_PDO/mon.php','2017-04-13 22:13:29'),(17975,'192.168.167.51','aktion.php','/dev/statusMonitor_PDO/index.php?site=aktion&PHPSESSID=7erciavp5u58qudkm0ols3gq51','2017-04-13 22:13:35'),(17976,'192.168.167.51','admin.php','/dev/statusMonitor_PDO/index.php?site=admin&PHPSESSID=7erciavp5u58qudkm0ols3gq51','2017-04-13 22:13:36'),(17977,'192.168.167.51','admin.php','/dev/statusMonitor_PDO/index.php?site=admin&PHPSESSID=7erciavp5u58qudkm0ols3gq51','2017-04-13 22:13:36'),(17978,'192.168.167.51','admin.php','/dev/statusMonitor_PDO/index.php?site=admin&admsite=monitor&PHPSESSID=7erciavp5u58qudkm0ols3gq51','2017-04-13 22:13:37'),(17979,'192.168.167.51','admin.php','/dev/statusMonitor_PDO/index.php?site=admin&admsite=monitor&PHPSESSID=7erciavp5u58qudkm0ols3gq51','2017-04-13 22:13:37'),(17980,'192.168.167.51','adm_resource.php','/dev/statusMonitor_PDO/index.php?site=admin&admsite=monitor&PHPSESSID=7erciavp5u58qudkm0ols3gq51','2017-04-13 22:13:37'),(17981,'192.168.167.51','admin.php','/dev/statusMonitor_PDO/index.php?site=admin&admsite=optionen&PHPSESSID=7erciavp5u58qudkm0ols3gq51','2017-04-13 22:13:46'),(17982,'192.168.167.51','admin.php','/dev/statusMonitor_PDO/index.php?site=admin&admsite=optionen&PHPSESSID=7erciavp5u58qudkm0ols3gq51','2017-04-13 22:13:46'),(17983,'192.168.167.51','adm_optionen.php','/dev/statusMonitor_PDO/index.php?site=admin&admsite=optionen&PHPSESSID=7erciavp5u58qudkm0ols3gq51','2017-04-13 22:13:46'),(17984,'192.168.167.51','admin.php','/dev/statusMonitor_PDO/index.php?site=admin&admsite=optionen&PHPSESSID=7erciavp5u58qudkm0ols3gq51','2017-04-13 22:13:51'),(17985,'192.168.167.51','admin.php','/dev/statusMonitor_PDO/index.php?site=admin&admsite=optionen&PHPSESSID=7erciavp5u58qudkm0ols3gq51','2017-04-13 22:13:51'),(17986,'192.168.167.51','adm_optionen.php','/dev/statusMonitor_PDO/index.php?site=admin&admsite=optionen&PHPSESSID=7erciavp5u58qudkm0ols3gq51','2017-04-13 22:13:51'),(17987,'192.168.167.51','admin.php','/dev/statusMonitor_PDO/index.php?site=admin&admsite=optionen&PHPSESSID=7erciavp5u58qudkm0ols3gq51','2017-04-13 22:13:52'),(17988,'192.168.167.51','admin.php','/dev/statusMonitor_PDO/index.php?site=admin&admsite=optionen&PHPSESSID=7erciavp5u58qudkm0ols3gq51','2017-04-13 22:13:52'),(17989,'192.168.167.51','adm_optionen.php','/dev/statusMonitor_PDO/index.php?site=admin&admsite=optionen&PHPSESSID=7erciavp5u58qudkm0ols3gq51','2017-04-13 22:13:52'),(17990,'192.168.167.51','monitor_popup.php','/dev/statusMonitor_PDO/mon.php','2017-04-13 22:13:55'),(17991,'192.168.167.51','monitor.php','/dev/statusMonitor_PDO/mon.php','2017-04-13 22:13:55'),(17992,'192.168.167.51','monitor_popup.php','/dev/statusMonitor_PDO/monitor_popup.php?monitorid=24&PHPSESSID=7erciavp5u58qudkm0ols3gq51','2017-04-13 22:18:55'),(17993,'192.168.167.51','monitor_popup.php','/dev/statusMonitor_PDO/mon.php','2017-04-13 22:19:42'),(17994,'192.168.167.51','monitor.php','/dev/statusMonitor_PDO/mon.php','2017-04-13 22:19:42'),(17995,'192.168.167.51','monitor_popup.php','/dev/statusMonitor_PDO/mon.php','2017-04-13 22:20:09'),(17996,'192.168.167.51','monitor.php','/dev/statusMonitor_PDO/mon.php','2017-04-13 22:20:09'),(17997,'127.0.0.1','mon_upload.php','/dev/statusMonitor_PDO/mon_upload.php?mon=&status=1','2017-04-13 22:20:44'),(17998,'127.0.0.1','mon_upload.php','/dev/statusMonitor_PDO/mon_upload.php?mon=&status=0','2017-04-13 22:20:50'),(17999,'192.168.167.51','admin.php','/dev/statusMonitor_PDO/index.php?site=admin&admsite=monitor&PHPSESSID=7erciavp5u58qudkm0ols3gq51','2017-04-13 22:20:59'),(18000,'192.168.167.51','admin.php','/dev/statusMonitor_PDO/index.php?site=admin&admsite=monitor&PHPSESSID=7erciavp5u58qudkm0ols3gq51','2017-04-13 22:20:59'),(18001,'192.168.167.51','adm_resource.php','/dev/statusMonitor_PDO/index.php?site=admin&admsite=monitor&PHPSESSID=7erciavp5u58qudkm0ols3gq51','2017-04-13 22:20:59'),(18002,'127.0.0.1','mon_upload.php','/dev/statusMonitor_PDO/mon_upload.php?mon=&status=0','2017-04-13 22:21:21'),(18003,'127.0.0.1','mon_upload.php','/dev/statusMonitor_PDO/mon_upload.php?mon=test&status=0','2017-04-13 22:21:32'),(18004,'127.0.0.1','mon_upload.php','/dev/statusMonitor_PDO/mon_upload.php?mon=test&status=1','2017-04-13 22:21:35'),(18005,'192.168.167.51','monitor_popup.php','/dev/statusMonitor_PDO/monitor_popup.php?monitorid=24&PHPSESSID=7erciavp5u58qudkm0ols3gq51','2017-04-13 22:21:39'),(18006,'192.168.167.51','monitor_popup.php','/dev/statusMonitor_PDO/monitor_popup.php?logfileid=2','2017-04-13 22:21:41'),(18007,'192.168.167.51','monitor_popup.php','/dev/statusMonitor_PDO/monitor_popup.php?monitorid=24&PHPSESSID=7erciavp5u58qudkm0ols3gq51','2017-04-13 22:23:14');
/*!40000 ALTER TABLE `sys_log_visits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_monitor`
--

DROP TABLE IF EXISTS `sys_monitor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_monitor` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `descr` text NOT NULL,
  `timeout` int(10) unsigned NOT NULL DEFAULT '0',
  `indx` int(10) unsigned NOT NULL DEFAULT '0',
  `groups` varchar(32) NOT NULL,
  `displayname` varchar(128) NOT NULL,
  `active` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_indx` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_monitor`
--

LOCK TABLES `sys_monitor` WRITE;
/*!40000 ALTER TABLE `sys_monitor` DISABLE KEYS */;
INSERT INTO `sys_monitor` VALUES (24,'test','TestMonitor',120,0,'Allgemein','TestMonitor',1);
/*!40000 ALTER TABLE `sys_monitor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_monitor_log`
--

DROP TABLE IF EXISTS `sys_monitor_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_monitor_log` (
  `mon_id` int(10) unsigned NOT NULL,
  `message` varchar(128) NOT NULL,
  `toc_ts` datetime NOT NULL,
  `status` tinyint(3) unsigned NOT NULL,
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `logfile_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `indx_toc_ts` (`toc_ts`),
  KEY `indx_mon_id` (`mon_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_monitor_log`
--

LOCK TABLES `sys_monitor_log` WRITE;
/*!40000 ALTER TABLE `sys_monitor_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_monitor_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_monitor_logfile`
--

DROP TABLE IF EXISTS `sys_monitor_logfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_monitor_logfile` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `mon_id` int(10) unsigned NOT NULL,
  `log_id` int(10) unsigned NOT NULL,
  `toc_ts` datetime NOT NULL,
  `content` longblob NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_monitor_logfile`
--

LOCK TABLES `sys_monitor_logfile` WRITE;
/*!40000 ALTER TABLE `sys_monitor_logfile` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_monitor_logfile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_monitor_status`
--

DROP TABLE IF EXISTS `sys_monitor_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_monitor_status` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `toc_ts` datetime NOT NULL,
  `status` tinyint(3) unsigned NOT NULL,
  `monitor_name` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `monitor_name_indx` (`monitor_name`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_monitor_status`
--

LOCK TABLES `sys_monitor_status` WRITE;
/*!40000 ALTER TABLE `sys_monitor_status` DISABLE KEYS */;
INSERT INTO `sys_monitor_status` VALUES (1,'2014-12-30 15:26:03',1,'odb2_backup_orcl2'),(2,'2014-12-29 16:59:22',1,'odb2_backup_orcl5'),(3,'2014-12-29 17:11:06',1,'odb2_backup_orcl3'),(4,'2014-12-29 17:11:13',1,'odb2_backup_orcl8'),(5,'2017-04-13 22:21:35',1,'test'),(6,'2017-04-13 22:20:44',1,'0');
/*!40000 ALTER TABLE `sys_monitor_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_reload`
--

DROP TABLE IF EXISTS `sys_reload`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_reload` (
  `session_id` varchar(32) NOT NULL,
  `rel` int(10) unsigned NOT NULL,
  `toc_ts` datetime NOT NULL,
  PRIMARY KEY (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_reload`
--

LOCK TABLES `sys_reload` WRITE;
/*!40000 ALTER TABLE `sys_reload` DISABLE KEYS */;
INSERT INTO `sys_reload` VALUES ('4f19acc166c7692e1c392645fd1306d6',0,'2017-04-13 22:20:09'),('a356d3473d8d66ffb267924b3890c288',0,'2017-04-13 22:19:42');
/*!40000 ALTER TABLE `sys_reload` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_session`
--

DROP TABLE IF EXISTS `sys_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_session` (
  `sessionid` varchar(64) NOT NULL,
  `toc` datetime NOT NULL,
  `seconds` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`sessionid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_session`
--

LOCK TABLES `sys_session` WRITE;
/*!40000 ALTER TABLE `sys_session` DISABLE KEYS */;
INSERT INTO `sys_session` VALUES ('7erciavp5u58qudkm0ols3gq51','2017-04-13 22:24:03',1492115043);
/*!40000 ALTER TABLE `sys_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_statistic`
--

DROP TABLE IF EXISTS `sys_statistic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_statistic` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `site` varchar(100) NOT NULL DEFAULT '',
  `Alias` varchar(100) NOT NULL DEFAULT '',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `hits_current_day` int(10) unsigned NOT NULL DEFAULT '0',
  `toc` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `hits_050122` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=42 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_statistic`
--

LOCK TABLES `sys_statistic` WRITE;
/*!40000 ALTER TABLE `sys_statistic` DISABLE KEYS */;
INSERT INTO `sys_statistic` VALUES (34,'monitor_popup.php','',10,10,'2017-04-13 22:23:14',0),(35,'monitor.php','',8,8,'2017-04-13 22:20:09',0),(36,'aktion.php','',4,4,'2017-04-13 22:13:35',0),(37,'login.php','',3,3,'2017-04-13 22:10:14',0),(38,'admin.php','',14,14,'2017-04-13 22:20:59',0),(39,'adm_resource.php','',2,2,'2017-04-13 22:20:59',0),(40,'adm_optionen.php','',3,3,'2017-04-13 22:13:52',0),(41,'mon_upload.php','',5,5,'2017-04-13 22:21:35',0);
/*!40000 ALTER TABLE `sys_statistic` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_users`
--

DROP TABLE IF EXISTS `sys_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_users` (
  `userid` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(50) DEFAULT NULL,
  `vorname` varchar(100) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `passwordmd5` varchar(64) DEFAULT NULL,
  `groupid` int(11) DEFAULT NULL,
  `disable` tinyint(4) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `nickname` varchar(64) NOT NULL,
  `valid_to` datetime NOT NULL,
  `nologin` smallint(5) unsigned NOT NULL DEFAULT '0',
  `mobil` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=MyISAM AUTO_INCREMENT=66 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_users`
--

LOCK TABLES `sys_users` WRITE;
/*!40000 ALTER TABLE `sys_users` DISABLE KEYS */;
INSERT INTO `sys_users` VALUES (1,'admin','Volker','Losch','83b5f62ec6b23e88e29a67b107a7f82d',10,0,'vlosch@gmx.net','2017-04-13 22:10:14','','2030-01-01 00:00:00',0,''),(64,'vlosch1','Volker','Losch',NULL,NULL,0,'vlosch@gmx.net',NULL,'','2018-02-09 00:00:00',0,'295671420');
/*!40000 ALTER TABLE `sys_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_values`
--

DROP TABLE IF EXISTS `sys_values`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_values` (
  `name_s` varchar(45) NOT NULL,
  `val_s` varchar(255) NOT NULL,
  `descr_s` varchar(128) NOT NULL,
  `auto_edit` smallint(5) unsigned NOT NULL,
  `indx` int(10) unsigned NOT NULL,
  `typ` varchar(45) NOT NULL,
  PRIMARY KEY (`name_s`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_values`
--

LOCK TABLES `sys_values` WRITE;
/*!40000 ALTER TABLE `sys_values` DISABLE KEYS */;
INSERT INTO `sys_values` VALUES ('cnt_log_view','20','Anzeige von n letzten Logeintr&auml;gen',1,120,'number'),('color_fail','#FF0000','Farbe des Monitors bei Fehler',1,104,'text'),('color_ok','#00FF00','Farbe des Monitors wenn alles Ok ist',1,100,'text'),('color_timeout','#FFFF00','Farbe des Monitors bei &uuml;berschrittenem Timeout',1,102,'text'),('color_unknown','#FFFFFF','Farbe Monitor bei unknown',1,105,'text'),('DEBUG','0','DEBUG 1: an 0: aus ',1,120,'number'),('display_refresh','1000','Refresh der Anzeige in Millisekunden',1,140,'number'),('monitor_row_cnt','4','Anzahl Monitore nebeneinander',1,110,'number'),('telegram_url','http://127.0.0.1/dev/telegram-bot/inbox.php','URL f&uuml;r telegram server<br>Neustart des checkscripts erforderlich',1,120,'text'),('test','warnung','',0,0,''),('title','Status Monitor','Titel der Webseite',1,90,'text');
/*!40000 ALTER TABLE `sys_values` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-04-13 22:24:03
